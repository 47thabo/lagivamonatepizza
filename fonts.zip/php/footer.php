<?php
echo "  
    <footer>
        <div>
            <div class=\"f-row\">
                <div class=\"col-12\">
                    <div class=\"footer-head\">
                        <h1>Lagiva Monate Pizza</h1>
                    </div>
                    <div class=\"our-mission-cont col-6\">
                        <div class=\"row mx-2 dongle-b-font\">
                            <h3 dongle-b-font>Our Mission</h3>
                        </div>
                        <div class=\"row mx-2\">
                            <p> </br> Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem ducimus possimus consequatur aliquid quis! Culpa, dicta. Quos id cupiditate minus reprehenderit nostrum.</p>
                        </div>
                        
                    </div>

                    <div class=\"links-cont\">
                        <ul class=\"link-list\">
                            <a href=\"#\" class=\"list-item\">Home</a>
                            <a href=\"about.php\" class=\"list-item\">About Us</a>
                            <a href=\"admin/index.php\" class=\"list-item\">Admin</a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
"
?>

